telegram.ext.BaseHandler
========================

.. autoclass:: telegram.ext.BaseHandler
    :members:
    :show-inheritance:
