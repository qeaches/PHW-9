telegram.ReplyKeyboardRemove
============================

.. autoclass:: telegram.ReplyKeyboardRemove
    :members:
    :show-inheritance:
