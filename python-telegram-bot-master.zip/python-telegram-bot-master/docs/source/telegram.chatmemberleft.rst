telegram.ChatMemberLeft
=======================

.. autoclass:: telegram.ChatMemberLeft
    :members:
    :show-inheritance:
