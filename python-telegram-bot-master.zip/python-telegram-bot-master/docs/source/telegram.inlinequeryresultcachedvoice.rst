telegram.InlineQueryResultCachedVoice
=====================================

.. autoclass:: telegram.InlineQueryResultCachedVoice
    :members:
    :show-inheritance:
