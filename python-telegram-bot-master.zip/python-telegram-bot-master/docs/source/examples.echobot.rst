``echobot.py``
==============

.. literalinclude:: ../../examples/echobot.py
   :language: python
   :linenos:
    