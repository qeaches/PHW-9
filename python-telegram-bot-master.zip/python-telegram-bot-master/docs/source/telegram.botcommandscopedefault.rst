telegram.BotCommandScopeDefault
===============================

.. autoclass:: telegram.BotCommandScopeDefault
    :members:
    :show-inheritance: