telegram.InlineQueryResultCachedGif
===================================

.. autoclass:: telegram.InlineQueryResultCachedGif
    :members:
    :show-inheritance:
