Stickers
--------

.. toctree::

    telegram.maskposition
    telegram.sticker
    telegram.stickerset
