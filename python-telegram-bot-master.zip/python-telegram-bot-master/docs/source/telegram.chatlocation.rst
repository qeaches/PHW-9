telegram.ChatLocation
=====================

.. autoclass:: telegram.ChatLocation
    :members:
    :show-inheritance:
