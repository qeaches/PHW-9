telegram.ext.ChatJoinRequestHandler
===================================

.. autoclass:: telegram.ext.ChatJoinRequestHandler
    :members:
    :show-inheritance:
