telegram.request.HTTPXRequest
=============================

.. autoclass:: telegram.request.HTTPXRequest
    :members:
    :show-inheritance: