telegram.ext.Job
=====================

.. autoclass:: telegram.ext.Job
    :members:
    :show-inheritance:
    :special-members: __call__
