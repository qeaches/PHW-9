telegram.VideoNote
==================

.. Also lists methods of _BaseThumbedMedium, but not the ones of TelegramObject

.. autoclass:: telegram.VideoNote
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject