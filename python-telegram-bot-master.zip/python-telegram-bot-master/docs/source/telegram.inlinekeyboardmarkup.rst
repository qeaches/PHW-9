telegram.InlineKeyboardMarkup
=============================

.. autoclass:: telegram.InlineKeyboardMarkup
    :members:
    :show-inheritance:
