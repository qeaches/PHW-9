telegram.SecureData
===================

.. autoclass:: telegram.SecureData
    :members:
    :show-inheritance:
