Games
-----

.. toctree::

    telegram.callbackgame
    telegram.game
    telegram.gamehighscore
