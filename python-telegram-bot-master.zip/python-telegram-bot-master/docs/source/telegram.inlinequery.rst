telegram.InlineQuery
====================

.. autoclass:: telegram.InlineQuery
    :members:
    :show-inheritance:
