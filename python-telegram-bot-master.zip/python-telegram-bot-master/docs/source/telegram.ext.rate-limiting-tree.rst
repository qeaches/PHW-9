Rate Limiting
-------------

.. toctree::

    telegram.ext.baseratelimiter
    telegram.ext.aioratelimiter