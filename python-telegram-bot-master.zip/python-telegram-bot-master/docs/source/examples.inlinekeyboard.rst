``inlinekeyboard.py``
=====================

.. literalinclude:: ../../examples/inlinekeyboard.py
   :language: python
   :linenos:
    