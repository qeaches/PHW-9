Arbitrary Callback Data
-----------------------

.. toctree::

    telegram.ext.callbackdatacache
    telegram.ext.invalidcallbackdata
