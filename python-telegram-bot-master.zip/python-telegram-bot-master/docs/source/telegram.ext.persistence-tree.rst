Persistence
-----------

.. toctree::

    telegram.ext.basepersistence
    telegram.ext.dictpersistence
    telegram.ext.persistenceinput
    telegram.ext.picklepersistence
